<?php
    Header("Location:./setp1.php");
    ?>