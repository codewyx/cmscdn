<?php
echo "
<script>
var myjinrishici = document.getElementById('hitokoto');
myjinrishici.innerHTML = "<span id="jinrishici-sentence">正在加载今日诗词....</span><script src="https://sdk.jinrishici.com/v2/browser/jinrishici.js" charset="utf-8"></script>";
</script>
";
?>