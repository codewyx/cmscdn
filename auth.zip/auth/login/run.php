<?php

function send_post($url, $header, $post_data)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($post_data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}

$head =  array(
    'header' => 'Content-type:application/json; charset=utf-8',
);

$data = array(
    'pid' => '65edCTyg',
    'identity' => $_POST["username"],
    'password'=> $_POST["password"],
);
$result = json_decode(send_post('https://api.codemao.cn/tiger/v3/web/accounts/login', $head, $data),true);
if($result["auth"]!=null){
    header('Content-Type:application/json; charset=utf-8');
    $arr = array('code'=>200,'message'=>"登录成功",'id'=>$result["user_info"]["id"],'username'=>$result["user_info"]["nickname"],'avatar'=>$result["user_info"]["avatar_url"]);
    echo(json_encode($arr));  
}else{
    header('Content-Type:application/json; charset=utf-8');
    $arr = array('code'=>100,'message'=>"信息错误");
    echo(json_encode($arr));  
}

