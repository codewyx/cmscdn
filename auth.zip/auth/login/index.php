<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>RapidAuth 授权</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Sans+SC:100,300,400,500,700,900">
  <link rel="stylesheet" href="style.css" />

</head>

<body>
  <div class="flex-col justify-start items-center page">
    <div class="flex-col section">
      <div class="flex-row items-center group space-x-5">
        <div class="flex-col justify-start items-center image-wrapper-2">
          <img class="image" src="<? echo $_GET['img']?$_GET['img']:"https://codefun-proj-user-res-1256085488.cos.ap-guangzhou.myqcloud.com/643a3e4b5a7e3f03100ecb6c/648ec8fa726ab50011f23a94/16870794674807656831.png"?>
" />
        </div>
        <div class="flex-col justify-start items-center image-wrapper">
          <img class="image_2" src="https://codefun-proj-user-res-1256085488.cos.ap-guangzhou.myqcloud.com/643a3e4b5a7e3f03100ecb6c/648ec8fa726ab50011f23a94/16870794674900696021.png" />
        </div>
        <div class="flex-col justify-start items-center image-wrapper">
          <img class="image" src="./ttt.png" />
        </div>
      </div>
      <form action="run.php" method="POST">
        <br><br>
      <span class="text"><? echo $_GET['title']?$_GET['title']:"未提供名称"?> 请求授权你的 编程猫 帐号</span>
      <div class="flex-col group_2">
        <span class="self-start font_1 text_2">用户名/手机/邮箱</span>
        <input class="section_2" name="username" required="required" />

        <span class="self-start text_3">密码</span>
        <input class="section_2" name="password" type="password" required="required" />
        <div class="flex-row group_3 space-x-34">
          <div class="flex-col justify-start items-start section_3">
          <button onclick="window.location.href='about:blank'; window.close();" class="flex-col justify-start items-center text-wrapper button"><span class="font_1  text_4">拒绝</span></button>
     
          </div>
          <button type="submit" class="flex-col justify-start items-center text-wrapper_2 button"><span class="font_1  text_5">授权登录</span></button>
        </div>
      </div>
      </form>
      <div class="flex-col items-start group_4 space-y-4">
        <span class="font_2">应用会获取以下权限：</span>
        <span class="font_2 text_6">· 用户信息 (ID、昵称、头像)</span>
      </div>
    </div>
  </div>
  </div>
</body>

</html>