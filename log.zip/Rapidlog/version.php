<?php
$infor["name"]="Rapidlog";
$infor["version"]="1.0.1";
$infor["author"]="SUDA_CODE";
?>