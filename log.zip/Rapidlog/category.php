<?php include("head-menu.php") ?>
<div class="card-awaaaaa" style="margin:auto;overflow:auto;position: absolute;left: calc(40% - 20px);top: 9%;width: calc(62% - 12px);    height: 88%;">


    <div class="mdui-text-color-black  ">
        <br>
        <div class="mdui-container">
            
        <?php include("get-sql-article-of-category.php") ?>   
    </div>

</div>
<?php include("login-logon-onload.php") ?>