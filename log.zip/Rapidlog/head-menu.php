<body
    class=" mdui-appbar-with-toolbar mdui-theme-accent-indigo mdui-theme-primary-indigo mdui-text-color-white mdui-drawer-body-left"
    style="--color-primary: 63, 81, 181; --color-accent: 63, 81, 181;">
    <div class="loginlogon"
        style="display: flex; flex-direction: row; gap: 10px; position: fixed; right: 11px; top: 11px;z-index: 9999999;">
        <?php
        function encode($string = '', $skey = 'cxphp')
        {
            $strArr = str_split(base64_encode($string));
            $strCount = count($strArr);
            foreach (str_split($skey) as $key => $value)
                $key < $strCount && $strArr[$key] .= $value;
            return str_replace(array('=', '+', '/'), array('O0O0O', 'o000o', 'oo00o'), join('', $strArr));
        }

        define('BASE_PATH', str_replace('\\', '/', realpath(dirname(__FILE__) . '/')) . "/");
        define('BASE_PATH1', str_replace('\\', '/', realpath(dirname(BASE_PATH) . '/')) . "/");
        $json_string = file_get_contents(BASE_PATH1 . '/install/sql-config/sql.json');
        $dataxxx = json_decode($json_string, true);
        $link = mysqli_connect($dataxxx['server'], $dataxxx['dbusername'], $dataxxx['dbpassword'], $dataxxx['dbname']);
        $sql = "select password from `rapidcmsuser` where username=\"" . $_COOKIE["name"] . "\"";
        $result = mysqli_query($link, $sql);
        $pass = mysqli_fetch_row($result);
        $pa = $pass[0];

        if ($_COOKIE["user"] == encode($_COOKIE["name"], $pa) && $_COOKIE["user"] != "") {
            echo '<div mdui-menu="{target: \'#logout-menu\'}" class="mdui-typo  mdui-btn mdui-ripple more-option mdui-color-theme-600" >[用户] ' . $_COOKIE["name"] . '<i style="color:white!important" class="mdui-text-color-white mdui-icon material-icons mdui-text-color-theme-icon">arrow_drop_down</i></div>';
        } else {
            echo '<div class="mdui-btn mdui-btn-dense mdui-color-theme-600"  onclick="document.getElementById(\'login\').style.zIndex=999999" mdui-dialog="{target: \'#login\'}">登录</div><div class="mdui-btn mdui-btn-dense mdui-color-theme-600" onclick="document.getElementById(\'logon\').style.zIndex=999999" mdui-dialog="{target: \'#logon\'}">注册</div>';
        }
        ?>
    </div>
    <!-- <div class="mdui-toolbar mdui-color-theme mdui-text-color-white mdui-appbar mdui-appbar-fixed mdui-headroom">
        <button class="drawer mdui-btn mdui-btn-icon mdui-ripple" mdui-drawer="{target: '#drawer', swipe: true}"><i class="mdui-icon material-icons">menu</i></button>
        <span class="mdui-typo-title"><? echo $data_header["title"]; ?></span>
        <div class="mdui-toolbar-spacer"></div>
        <?php
        if ($_COOKIE["user"] == "0BE2B5EE579A466B5BE1EA7A44754D1B85FCAE49D17323CA819DD8D4ABDC584E") {
            echo '<button mdui-menu="{target: \'#logout-menu\'}" class=" mdui-color-theme-600 mdui-typo mdui-btn mdui-ripple more-option">[用户] ' . $_COOKIE["name"] . '<i style="color:white!important" class="mdui-text-color-white mdui-icon material-icons mdui-text-color-theme-icon">arrow_drop_down</i></button>';
        } else {
            echo '<div class="mdui-btn mdui-btn-dense mdui-color-theme-600" onclick="document.getElementById(\'login\').style.zIndex=999999" mdui-dialog="{target: \'#login\'}">登录</div><div class="mdui-btn mdui-btn-dense mdui-color-theme-600" onclick="document.getElementById(\'logon\').style.zIndex=999999" mdui-dialog="{target: \'#logon\'}">注册</div>';
        }
        ?>
        <ul class="mdui-menu" id="logout-menu" style="transform-origin: 0px 100%">
      <li class="mdui-menu-item"><a class="mdui-ripple" href="../../../../resource/logout.php">退出登录</a></li>

        </ul>
    </div> -->
    <!-- 
    <div style="color:black;" class="mdui-drawer mdui-drawer-open mc-drawer" id="drawer">
        <ul class="mdui-list">
            <a href="../../../../../index.php">
                <li class="mdui-list-item mdui-ripple" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe88a;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">首页</div>
                </li>
            </a>
            <div class="mdui-divider"></div>
            <?php
            include("get-sql-category.php")
                ?>

        </ul>
        <div class="mdui-typo" style=" position: absolute;bottom:0%;   box-sizing: border-box; width: 100%;  padding: 20px 16px;">
            <h4> <small>© 2023 RapidTeam</small><br> <small>Powered and Theme by RapidTeam
                </small></h4>
        </div>
    </div> -->


    </div>
    <style>
        * {
            font-family: "MiSans", system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }

        .blogwork {
            position: absolute;
            left: 150px;
            top: 39%;
            text-align: center;
            display: flex;
            gap: 15px;
            flex-direction: column;
            align-items: center;
        }

        .blogwork * {
            margin: 0;
        }

        .mdui-tab a {
            -webkit-transition: all 0.5s;
            transition: all 0.5s;
        }

        .mdui-tab .mdui-tab-active {
            color: #ffffff;
            opacity: 1;
            background: #1a73e869 !important;
            border-radius: 6px;
        }

        .mdui-tab-indicator {
            display: none;
        }

        .mdui-icon {
            display: inline-block !important;
        }

        .mc-list-item {
            position: relative !important;
        }
    </style>


    <div class="blogwork">
        <div class="mdui-ripple" style="Border-radius: 100%;    height: 100px;">
            <img style="Border-radius: 100%;" width="100" src="../../../resource/img/icon.png">
        </div>
        <h1 style="font-weight: 600;color: #000000;">
            <? echo $data_header["title"]; ?>
        </h1>
        <p style="font-weight: 400;color: #000000;">
            <? echo $data_header["introduce"]; ?>
        </p>
    </div>
    <div class="mdui-tab" mdui-tab="" style="position: absolute;left: 40%;top: 5%;">
        <?php
        include("get-sql-category.php")
            ?>
    </div>

    <style>
        @media (max-width: 900px) {

            html,
            body {
                display: flex;
                flex-direction: column;
                align-items: center;
                background-color: #ffffff !important;
                width: 100%;
            }

            body>* {
                position: static !important;
            }

            #page-question {
                position: static !important;
            }

            .mdui-tab {
                margin-top: 20px;
            }

            .mdui-card {
                position: relative !important;
            }

            .mc-list-item .mc-user-popover {
                position: absolute !important;
            }

            .mdui-container {
                width: 100%;
                max-width: 1100px;
                padding: 5px 40px;
            }

            .card-awaaaaa {
                padding: 10px 0;
                width: 100% !important;
            }

            .loginlogon {
                position: absolute !important;
            }
        }
    </style>

    <?php
    function curPageURL()
    {
        $pageURL = 'http';
        if ($_SERVER["HTTPS"] == "on") {
            $pageURL .= "s";
        }
        $pageURL .= "://";
        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
        } else {
            $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
        }
        return $pageURL;
    }
    ?>