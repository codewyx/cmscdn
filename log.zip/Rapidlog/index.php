<?php
include("resource/variable.php");
include("head-menu.php") ?>
<?php
    error_reporting(0);
    header("Content-type:text/html;charset=utf-8");
    $table_name = "rapidcmscategory";
    $json_string = file_get_contents($_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['HTTP_HOST'] . '/install/sql-config/sql.json');
    $data = json_decode($json_string, true);
    $conn = mysqli_connect($data['server'], $data['dbusername'], $data['dbpassword'], $data['dbname']);
    $sql = 'select * from `'.$table_name .'` ORDER BY num DESC';
    $res = mysqli_query($conn, $sql);
    $colums = mysqli_num_fields($res);
    $row = mysqli_fetch_row($res);
    echo "<script>window.open('/category/?id=".$row[0]."','_self');</script>";
?>

<?php include("login-logon-onload.php") ?>