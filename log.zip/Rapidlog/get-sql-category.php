<?php
error_reporting(0);
header("Content-type:text/html;charset=utf-8");
$table_name = "rapidcmscategory";
$json_string = file_get_contents($_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['HTTP_HOST'] . '/install/sql-config/sql.json');
$data = json_decode($json_string, true);
$conn = mysqli_connect($data['server'], $data['dbusername'], $data['dbpassword'], $data['dbname']);
$sql = 'select * from `' . $table_name . '` ORDER BY num DESC';
$res = mysqli_query($conn, $sql);
$colums = mysqli_num_fields($res);


$articleid = $_GET["id"]; //输入文字ID
$table_name = "rapidcmspage";


while ($row = mysqli_fetch_row($res)) {
    if ($row[0] == $_GET["id"]) {
        echo '<a class="mdui-ripple mdui-tab-active" href="../../../../category?id=' . $row[0] . '">';
    }
    else {
        echo '<a class="mdui-ripple" style="color: #000000;" href="../../../../category?id=' . $row[0] . '">';
    }
    echo $row[1];
    echo "</a>";
}

?>