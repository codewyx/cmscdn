<?php
$infor["name"]="极简风模板";
$infor["version"]="1.0.2";
$infor["author"]="Codewyx&SUDA_CODE";
?>