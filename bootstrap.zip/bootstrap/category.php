<?php include("head-menu.php") ?>
<div class="mdui-container" style="margin:auto;overflow:auto;">

<?php include("get-sql-article-of-category.php") ?>  

</div>
<?php include("login-logon-onload.php") ?>