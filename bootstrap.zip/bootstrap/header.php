<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mdui@1.0.2/dist/css/mdui.min.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mtu/dist/mtu.min.css">
<link rel="stylesheet" href="../../../../resource/css/style.css">
<link rel="stylesheet" href="https://cdn.w3cbus.com/mdui.org/static/theme/material/index.e8409b3c.css">
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <style>
    *{
    font-family: "MiSans",system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    .mdui-textfield-invalid-html5 .mdui-textfield-input, .mdui-textfield-invalid-html5.mdui-textfield-focus .mdui-textfield-input, .mdui-textfield-invalid.mdui-textfield-focus .mdui-textfield-input, .mdui-textfield-invalid .mdui-textfield-input {
    border-bottom-color: #0d6efd!important;
    box-shadow: 0 1px 0 0 #0d6efd!important;
}
.mdui-textfield-invalid-html5.mdui-textfield-floating-label .mdui-textfield-label, .mdui-textfield-invalid.mdui-textfield-floating-label .mdui-textfield-label {
    color: #0d6efd35!important;
}
.mdui-textfield-invalid-html5.mdui-textfield-floating-label.mdui-textfield-focus .mdui-textfield-label, .mdui-textfield-invalid-html5.mdui-textfield-floating-label.mdui-textfield-not-empty .mdui-textfield-label, .mdui-textfield-invalid.mdui-textfield-floating-label.mdui-textfield-focus .mdui-textfield-label, .mdui-textfield-invalid.mdui-textfield-floating-label.mdui-textfield-not-empty .mdui-textfield-label{
    color: #0d6efd!important;
}
.mdui-textfield-error {
    color: #0d6efd87;
    visibility: hidden;
}
.mdui-list-item:active{
    background-color: #eee;
}
*::selection {
    background:#0d6efd;
    color:#ffffff;
}
*::-moz-selection {
    background:#0d6efd;
    color:#ffffff;
}
*::-webkit-selection {
    background:#0d6efd;
    color:#ffffff;
}

</style>