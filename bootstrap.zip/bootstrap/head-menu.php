<body class=" mdui-appbar-with-toolbar mdui-theme-accent-indigo mdui-theme-primary-indigo mdui-text-color-white mdui-drawer-body-left" style="--color-primary: 63, 81, 181; --color-accent: 63, 81, 181;">
    <header style="padding-right:40px;z-index: 5099;position: fixed;width: 100%;left: 0;background: #ffffff;top: 0;" class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <div class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
        <button style="margin: 0 20px;" class="drawer mdui-btn mdui-btn-icon" mdui-drawer="{target: '#drawer', swipe: true}">
            <i class="mdui-icon material-icons">menu</i>
        </button>
        <span class="fs-4"><? echo $data_header["title"]; ?></span>
</div>

      <ul class="nav nav-pills">
      <?php
        if ($_COOKIE["user"] == "0BE2B5EE579A466B5BE1EA7A44754D1B85FCAE49D17323CA819DD8D4ABDC584E") {
            echo '<button mdui-menu="{target: \'#logout-menu\'}" class="btn more-option" >[用户] ' . $_COOKIE["name"] . '<i class="mdui-text-color-black mdui-icon material-icons mdui-text-color-theme-icon">arrow_drop_down</i></button>';
        } else {
            echo '<li class="nav-item"><button class="nav-link" onclick="document.getElementById(\'login\').style.zIndex=999999" mdui-dialog="{target: \'#login\'}">登录</a></li><li class="nav-item"><button class="nav-link active"onclick="document.getElementById(\'logon\').style.zIndex=999999" mdui-dialog="{target: \'#logon\'}">注册</a></li>';
        }
        ?>
      </ul>
    </header>

    <div style="color:black;padding-top:10px" class="mdui-drawer mdui-drawer-open mc-drawer" id="drawer">
        <ul class="mdui-list">
            <a href="../../../../#">
                <li class="mdui-list-item" style="font-size:15px!important">
                    <i class="mdui-list-item-icon mdui-icon material-icons">&#xe88a;</i>
                    <div class="mdui-list-item-content" style="font-size:15px!important">首页</div>
                </li>
            </a>
            <div class="mdui-divider"></div>
            <?php
            include("get-sql-category.php")
            ?>

        </ul>
        <div class="mdui-typo" style=" position: absolute;bottom:0%;   box-sizing: border-box; width: 100%;  padding: 20px 16px;">
            <h4> <small>© 2023 RapidTeam</small><br> <small>Theme by SUDA
                </small></h4>
        </div>
    </div>