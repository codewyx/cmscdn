<?php
error_reporting(0);
header("Content-type:text/html;charset=utf-8");
$table_name = "rapidcmspage";
$json_string = file_get_contents($_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['HTTP_HOST'] . '/install/sql-config/sql.json');
$data = json_decode($json_string, true);
$conn = mysqli_connect($data['server'], $data['dbusername'], $data['dbpassword'], $data['dbname']);
$sql = 'select * from `'.$table_name .'` WHERE categoryid="'.$cid.'"  ORDER BY time DESC';
$res = mysqli_query($conn, $sql);
$colums = mysqli_num_fields($res);
while ($row = mysqli_fetch_row($res)) {
    echo '<div class="item-list">';
    echo '   <a class="mc-list-item card" style="border-radius: 10px;" href="../../../../article/?id='.$row[0].'">';
    echo '    <div class="mc-user-popover"><i class="mdui-list-item-icon mdui-icon material-icons">description</i></div>';
    echo '   <div class="title mdui-text-color-theme-text">'.$row[1].'</div><div class="content mdui-text-color-theme-secondary">';
    echo '   <div class="snippet">'.$row[3].'  </div></div></a></div>';

}
?>
    
                       
                      
                          