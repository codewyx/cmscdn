<?php
error_reporting(0);
header("Content-type:text/html;charset=utf-8");
$table_name = "rapidcmspage";
$json_string = file_get_contents($_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['HTTP_HOST'] . '/install/sql-config/sql.json');
$data = json_decode($json_string, true);
$conn = mysqli_connect($data['server'], $data['dbusername'], $data['dbpassword'], $data['dbname']);
$sql = 'select * from `'.$table_name .'` WHERE id="'.$cid.'"';
$res = mysqli_query($conn, $sql);
$colums = mysqli_num_fields($res);
while ($row = mysqli_fetch_row($res)) {
    echo '<div class="card question"><h1 class="title">'.$row[1].'</h1>';
    echo '  <div class="mc-user-line"><div class="mc-user-popover"><span style="display: flex; color: #757575; align-items: center;"><i class="mdui-icon material-icons" style="margin: 0 5px 0 0">&#xe192;</i>'.$row[3].'</span>';
   $cont3 = htmlspecialchars_decode($row[2]);
    echo '  </div></div><div class="mdui-typo" style="padding: 12px 0 32px;">'.$cont3." </div>               ";
}
?>
    
<!-- <?php
error_reporting(0);
header("Content-type:text/html;charset=utf-8");
$table_name = "rapidcmscategory";
$json_string = file_get_contents($_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['HTTP_HOST'] . '/install/sql-config/sql.json');
$data = json_decode($json_string, true);
$conn = mysqli_connect($data['server'], $data['dbusername'], $data['dbpassword'], $data['dbname']);
$sql = 'select * from `'.$table_name .'` ORDER BY num DESC';
$res = mysqli_query($conn, $sql);
$colums = mysqli_num_fields($res);
while ($row = mysqli_fetch_row($res)) {
    echo '<div style="display: flex; justify-content: flex-end;">';
    echo '<a href="../../../../category?id='.$row[0].'" style=" display: flex; align-items: center; text-decoration: none; gap: 5px; flex-direction: row;color:#757575;">';
    echo '<i class="mdui-icon material-icons">&#xe892;</i>';
    echo '<div class="mdui-list-item-content">'.$row[1].'</div>';
    echo "</a>";
    echo "</div><br>";
    echo "</div>";

}
?> -->
             
               
                      
                          